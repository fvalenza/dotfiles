# everforest-gtk

A simple everforest gtk theme

### Installation:

Clone the repo into your `~/.themes` folder
```bash
mkdir ~/.themes
git clone https://github.com/theory-of-everything/everforest-gtk ~/.themes/everforest-gtk
```
Select Theme with you theme switch of choice (I use lxappearance for instance)
